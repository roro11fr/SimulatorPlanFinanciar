import os
import uuid
import random
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

from django.shortcuts import render, get_object_or_404, redirect
from django.conf import settings

from simulator.models import Simulation
from simulator.models import InvestmentPlan
from django.views.decorators.http import require_POST
from simulator.utils import get_historical_data

def monte_carlo_simulation_with_historical_data(initial, monthly, years=30, simulations=500, symbol="^GSPC", start_date="2010-01-01", end_date="2025-01-01"):
    """
    Simulare Monte Carlo utilizând randamentele istorice ale unui simbol financiar (de exemplu, S&P 500)
    """
    # Obține date istorice
    historical_data = get_historical_data(symbol, start_date, end_date)
    
    # Verificăm ce coloane sunt disponibile
    print(f"Columns in historical data: {historical_data.columns}")
    
    # Calculăm randamentele zilnice (pct. de schimbare zi cu zi)
    if ('Close', symbol) in historical_data.columns:
        historical_data['Daily Return'] = historical_data[('Close', symbol)].pct_change()
    else:
        raise ValueError("Nu am găsit o coloană 'Close' în datele istorice")
    
    # Continuăm cu calculul randamentelor anuale
    annual_returns = historical_data['Daily Return'].resample('Y').sum()  # Sumăm randamentele zilnice pe an
    
    # Folosim media și deviația standard a randamentelor anuale
    mean_return = annual_returns.mean()
    std_dev = annual_returns.std()
    
    # Creăm simulările
    results = []
    for _ in range(simulations):
        value = initial
        scenario = []
        for _ in range(years):
            annual_contribution = monthly * 12
            shock = np.random.normal(mean_return, std_dev)  # Generăm un șoc anual
            value = (value + annual_contribution) * (1 + shock)
            scenario.append(value)
        results.append(scenario)
    
    return np.array(results)

def plot_simulation(scenarios):
    arr = np.array(scenarios)
    print(f"Shape of arr before plotting: {arr.shape}")  # Verifică forma array-ului
    
    # Verifică dacă este un array 2D
    if len(arr.shape) == 2:
        mean = np.mean(arr, axis=0)  # Media pe fiecare an
        p10 = np.percentile(arr, 10, axis=0)  # Percentila 10
        p90 = np.percentile(arr, 90, axis=0)  # Percentila 90

        plt.figure(figsize=(10, 5))
        plt.fill_between(range(len(mean)), p10, p90, color='lightblue', alpha=0.4, label='10%-90%')
        plt.plot(mean, color='blue', label='Medie')
        plt.title("Evoluție simulată")
        plt.xlabel("Ani")
        plt.ylabel("Valoare (RON)")
        plt.legend()
        plt.grid(True)

        filename = f"simulation_{uuid.uuid4().hex}.png"
        path = os.path.join(settings.MEDIA_ROOT, 'simulations', filename)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        plt.savefig(path)
        plt.close()
        return f"simulations/{filename}"
    else:
        raise ValueError("Scenariile trebuie să fie într-un array 2D (n simulări x ani)")




def start_simulation(request, plan_id):
    plan = get_object_or_404(InvestmentPlan, id=plan_id, user=request.user)

    start = plan.start_date
    end = plan.end_date
    years = (end - start).days // 365

    # Folosim S&P 500 ca exemplu
    symbol = "^GSPC"
    start_date = start.strftime("%Y-%m-%d")
    end_date = end.strftime("%Y-%m-%d")

    scenarios = monte_carlo_simulation_with_historical_data(
        float(plan.initial_investment),
        float(plan.monthly_contribution),
        years=years,
        simulations=500,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date
    )

    print(f"Shape of scenarios before plotting: {scenarios.shape}")  # Verifică forma array-ului scenarios

    image_path = plot_simulation(scenarios)

    sim = Simulation.objects.create(
        investment_plan=plan,
        user=request.user,
        initial_investment=plan.initial_investment,
        risk_level=plan.risk_level,
        years=years,
        result_image_path=image_path,
        simulations_run=500
    )

    return render(request, 'simulator/simulare_resultate.html', {'simulare': sim})

def istoric_simulari(request):
    simulari = Simulation.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'simulator/istoric_simulari.html', {
        'simulari': simulari,
        'MEDIA_URL': settings.MEDIA_URL,
    })

@require_POST
def sterge_simulare(request, simulare_id):
    simulare = get_object_or_404(Simulation, id=simulare_id, user=request.user)
    
    # Șterge fișierul grafic, dacă există
    image_path = os.path.join(settings.MEDIA_ROOT, simulare.result_image_path)
    if os.path.exists(image_path):
        os.remove(image_path)

    simulare.delete()
    return redirect('istoric_simulari')  # asigură-te că numele URL-ului e corect
